# How to Deploy Your Portfolio

Your portfolio is built as a static HTML site, which makes it completely free and easy to deploy. Here are the 3 best ways to get it online:

## Option 1: Netlify Drop (Easiest - No Account Needed initially)
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
2. Open your file explorer on your computer.
3. Drag and drop the folder containing your `index.html` onto the Netlify page.
4. **Done!** You'll get a live URL immediately.

## Option 2: GitHub Pages (Best for Long Term)
1. Create a new repository on GitHub.com (e.g., `my-portfolio`).
2. Push this code to that repository:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/my-portfolio.git
   git branch -M main
   git push -u origin main
   ```
3. Go to Repository **Settings** > **Pages**.
4. Select "Deploy from branch" and choose `main` / `root`.
5. Your site will be live at `your-username.github.io/my-portfolio`.

## Option 3: Vercel (Fastest Global Performance)
1. Install Vercel CLI: `npm i -g vercel` (if you have Node.js).
2. Run `vercel` in this directory.
3. Follow the prompts (Say "Yes" to everything).
4. You'll get a production URL instantly.

---

## Customizing Before Deploy
Remember to open `index.html` and search/replace the following before sharing your link:
- "Alex Morgan" -> Your Name
- "alex@example.com" -> Your Email
- "Company X" -> Your actual history
- Update the metrics in the "Outcomes" section to match your real achievements.